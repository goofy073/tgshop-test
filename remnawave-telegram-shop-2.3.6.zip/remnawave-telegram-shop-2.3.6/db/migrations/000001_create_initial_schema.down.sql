DROP TABLE purchase;
DROP TABLE customer;
